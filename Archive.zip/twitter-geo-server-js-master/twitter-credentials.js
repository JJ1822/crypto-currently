/*
 * You need to supply your own values for the following keys.
 * Get yours at http://apps.twitter.com
 */
 let apiKeys = module.exports = {};

 apiKeys.mapKey = {
    consumer_key: 'e3LHuGHWvNMIIjC2wfe1DdmuD',
    consumer_secret: 'TDM7TflfnCdbFWaBmnp2IuCNIWcgIQAqR2Oq6R71PabtYCjfQM',
    access_token_key: '965352880902258688-7aQ1uh37Iaim5wgJvOUzbfPOFx81BgT',
    access_token_secret: 'SfVnt2ECOu0KO0MhQEFkHZA8U5Hse9mL7HdLKwvXOjb2B'
 };

 apiKeys.watsonKey = {
  consumer_key: 'FlbMS4GcrGnRZlNn9HX23nHhB',
  consumer_secret: '3fOR4yIBQjiSdTsUGMpnkMkI0NDyOyapAorjAZkcbxUaiUkS4B',
  access_token_key: '965675476181164032-57mbhUwoo7Dfz3tcQybt4N2TZCVHtQt',
  access_token_secret: 'T2FY3HP3cOEDk6Z2CTEkceMFYDb4466Bd8LxZnklKxuU3'
 };

 apiKeys.watsonTone = {
  username: "82981b9b-9c6f-4b03-a257-2c0987a70c54",
  password: "HkvM3H7LM5fl",
  version_date: '2017-02-27'
 };
