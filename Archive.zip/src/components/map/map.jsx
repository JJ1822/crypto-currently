import React from 'react';
import {Component} from 'react';


class TweetMap extends Component {

// ==================================================
// Render
// ==================================================
  render() {
    return (
      <div id="map"></div>
    );
  }

}


export default TweetMap;
