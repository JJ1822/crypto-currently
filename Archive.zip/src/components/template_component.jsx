import React from 'react';
import {Component} from 'react';


class Template extends Component {

// ==================================================
// Render
// ==================================================
  render() {
    return (

    );
  }

}


export default Template;
